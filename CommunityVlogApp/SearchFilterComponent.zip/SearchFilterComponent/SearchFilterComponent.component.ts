import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
// import 'rxjs/add/operator/debounceTime';
import { debounceTime, switchMap, distinctUntilChanged } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { query } from '@angular/core/src/render3';
// import { switchMap } from 'rxjs/add/operator/switchMap';
// import { distinctUntilChanged } from 'rxjs/add/operator/distinctUntilChanged';

@Component({
  selector: 'app-SearchFilterComponent',
  templateUrl: './SearchFilterComponent.component.html',
  styleUrls: ['./SearchFilterComponent.component.css']
})
export class SearchFilterComponentComponent implements OnInit {
  queryField: FormControl = new FormControl();
  results: any;
  nameSet: any[] = ["one", "two", "three"];
  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.queryField.valueChanges
    .pipe(debounceTime(200))
    // .pipe(distinctUntilChanged())
    .pipe(switchMap(
      (query) => this.searchStringInArray(query, this.nameSet)
    )).subscribe(res => this.results = res);
  }

 searchStringInArray (str, strArray): Observable<any> {
    for (var j=0; j<strArray.length; j++) {
        if (strArray[j].match(str)) return j.json();
    }
    // return -1;
}
    

  // searchText(queryString: string): Observable<any[]> {
  //   // return this.nameSet.includes(queryString);
  //   // return this.http.get<any[]>('{"Value1": "Value2"}');

  // }
  // search(queryString: string) {
    // let _URL = this.baseUrl + queryString;
    // return this._http.get(_URL);
    // return this.nameSet.includes(queryString);
    // return queryString;
    // this.nameSet.filter(function( queryString ) {
    //   return queryString.value === 1;
    // }
  //   var filteredArray = this.nameSet.filter(function( queryString ) {
  //     return queryString.value === 1;
  // });
  }
